#include "param.h"

const int  TCP_NO_DELAY_ACTIVATED = 1;
